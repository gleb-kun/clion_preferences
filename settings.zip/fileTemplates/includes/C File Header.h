#if ($HEADER_COMMENTS)
//
// Created by Gleb Alcybeev on ${DATE}.
// gleb.alcybeev@gmail.com
#if ($ORGANIZATION_NAME && $ORGANIZATION_NAME != "")
// Copyright (c) $YEAR ${ORGANIZATION_NAME}#if (!$ORGANIZATION_NAME.endsWith(".")).#end All rights reserved.
#end
//
#end

